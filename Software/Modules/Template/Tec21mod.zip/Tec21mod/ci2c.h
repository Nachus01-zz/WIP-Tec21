/* 
 * File:   ci2c.h
 * Author: Ignacius
 *
 * Created on 24 de octubre de 2016, 07:55 PM
 */

#ifndef CI2C_H
#define	CI2C_H

#include<pic16lf1705.h>
#include"types.h"

#endif	/* CI2C_H */

