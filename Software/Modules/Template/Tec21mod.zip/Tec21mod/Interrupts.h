/* 
 * File:   Interrupts.h
 * Author: Ignacius
 *
 * Created on 3 de noviembre de 2016, 05:28 PM
 */

#ifndef INTERRUPTS_H
#define	INTERRUPTS_H

#include<pic16lf1705.h>

void Interrupts_Init();

#endif	/* INTERRUPTS_H */

