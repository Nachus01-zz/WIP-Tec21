#include <pic16lf1705.h>

#include "ADC.h"

void ADC_Init()
{
    ADON=1;
    
    CHS4=0;
    CHS3=0;
    CHS2=1;
    CHS1=0;
    CHS0=0;
    
    ADFM=0;
    
    ADCON1bits.ADCS=1;
    
    ADNREF=0;
    
    ADCON0bits.GO=1;
}