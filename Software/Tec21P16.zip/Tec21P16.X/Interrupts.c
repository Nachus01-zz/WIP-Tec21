#include "Interrupts.h"

void Interrupts_Init()
{
    GIE=1;
    PEIE=1;
    
    TXIE=1;
    TXIF=0;
    
    RCIE=1;
    RCIF=0;
    
    ADIE=1;
    ADIF=0;
}