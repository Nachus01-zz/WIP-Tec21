#include "Miscelaneous.h"

void Miscelaneous_Init()
{
    //TX pin
    RC4PPS=RC4TX;
    
    //ADC pin
    TRISAbits.TRISA4=1;
    ANSELAbits.ANSA4=1;
    
    //Oscilator to 8MHz
    OSCCON=F8M;
   
}
