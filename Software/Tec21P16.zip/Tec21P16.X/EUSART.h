/* 
 * File:   EUSART.h
 * Author: Ignacius
 *
 * Created on 2 de noviembre de 2016, 06:36 PM
 */

#ifndef EUSART_H
#define	EUSART_H

#include<pic16lf1705.h>

void EUSART_Init();

#endif	/* EUSART_H */

