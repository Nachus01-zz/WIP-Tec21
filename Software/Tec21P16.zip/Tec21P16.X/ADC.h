/* 
 * File:   EDC.h
 * Author: Ignacius
 *
 * Created on 3 de noviembre de 2016, 05:42 PM
 */

#ifndef EDC_H
#define	EDC_H

#include<pic16lf1705.h>

void ADC_Init();




#endif	/* EDC_H */

