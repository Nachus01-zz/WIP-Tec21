/*
 * File:   Tec21P16main.c
 * Author: Ignacius
 *
 * Created on 2 de noviembre de 2016, 04:06 PM
 */

#include "Miscelaneous.h"
#include "EUSART.h"
#include "Interrupts.h"
#include "ADC.h"

unsigned char A='a';
/*/
void interrupt inter()
{
    if(ADIE&&ADIF)
    {
        ADIF=0;
        A=ADRESH;
        TXREG=A;
        GO=1;
    }
    if(TXIF&&TXIE)TXIF=0;
    TXREG=A;
}
//*/
void main(void) 
{
    Miscelaneous_Init();
    EUSART_Init();
    Interrupts_Init();
    ADC_Init();
    
    while(1)
    {
        
        //*/
        A=255-ADRESH;
        TX1REG=A;//DRESH;
        /*/
        //TX1REG='A';
        //*/
    }
}
