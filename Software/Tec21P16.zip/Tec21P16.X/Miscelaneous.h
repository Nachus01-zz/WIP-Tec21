/* 
 * File:   Miscelaneous.h
 * Author: Ignacius
 *
 * Created on 2 de noviembre de 2016, 05:45 PM
 */

#ifndef MISCELANEOUS_H
#define	MISCELANEOUS_H
#define RC4TX 0b10100
#define F8M 0b01110000

#include<pic16lf1705.h>

void Miscelaneous_Init();

#endif	/* MISCELANEOUS_H */

